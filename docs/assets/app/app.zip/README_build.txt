使用方式：

1. 進入這個資料夾：
   cd flet_web_cache_package

2. 確認檔名是 main.py。

3. 建置 Flet Web，使用本地資源，不走 CDN：
   flet build web --no-cdn

4. 把 loading 畫面、manifest、service worker 加進 build/web：
   python post_build_optimize.py

5. 上傳 build/web 內的所有檔案到你的網站空間。

注意：
- 第一次開啟仍然需要下載 Flet/Pyodide/Flutter 資源。
- 第二次之後會優先使用手機瀏覽器快取，從主畫面開啟會比較快。
- Firebase Auth/Database 請求不會被快取，避免資料不同步。
- 如果你改版後手機還是讀到舊版，請改 service-worker.js 裡的 CACHE_VERSION，例如 shopping-list-flet-v2。
