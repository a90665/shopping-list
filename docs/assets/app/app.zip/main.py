import flet as ft
import httpx
import datetime
import asyncio
import json

# --- 1. Firebase 配置 ---
PROJECT_ID = "ourshoppinglist-7e6c7"
API_KEY = "AIzaSyC5hpB-l_gLAAvH5hTDVobcHxu2x6Gju4I"
DB_URL = f"https://{PROJECT_ID}-default-rtdb.firebaseio.com"
AUTH_SIGNIN = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={API_KEY}"
AUTH_SIGNUP = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={API_KEY}"


def is_web_runtime():
    try:
        import pyodide  # noqa
        return True
    except Exception:
        return False


async def request_json(method, url, payload=None):
    method = method.upper()

    if is_web_runtime():
        from pyodide.http import pyfetch

        headers = {
            "Content-Type": "application/json"
        }

        kwargs = {
            "method": method,
            "headers": headers
        }

        if payload is not None and method not in ["GET", "DELETE"]:
            kwargs["body"] = json.dumps(payload)

        response = await pyfetch(url, **kwargs)
        text = await response.string()

        if not text:
            return {}

        try:
            return json.loads(text)
        except Exception:
            return {
                "raw": text,
                "status": response.status
            }

    async with httpx.AsyncClient(
        headers={
            "Accept-Encoding": "identity",
            "Content-Type": "application/json"
        },
        timeout=20.0
    ) as client:
        if method == "GET":
            response = await client.get(url)
        elif method == "POST":
            response = await client.post(url, json=payload)
        elif method == "PUT":
            response = await client.put(url, json=payload)
        elif method == "PATCH":
            response = await client.patch(url, json=payload)
        elif method == "DELETE":
            response = await client.delete(url)
        else:
            raise ValueError(f"Unsupported method: {method}")

        if not response.text:
            return {}

        return response.json()


async def main(page: ft.Page):
    page.title = "荳比小窩購物清單"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.window_width = 720
    page.window_height = 850
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.scroll = ft.ScrollMode.AUTO

    user_token = {"id": None}
    prefs = ft.SharedPreferences()

    current_list = {"name": None}

    err_text = ft.Text(color="red")

    shopping_container = ft.Column(
        visible=False,
        width=700,
        height=820,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=8
    )

    home_list_view = ft.Column(
        scroll=ft.ScrollMode.AUTO,
        height=640,
        width=660,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=8
    )

    items_view = ft.Column(
        scroll=ft.ScrollMode.AUTO,
        height=650,
        width=340,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=6
    )

    list_name_input = ft.TextField(
        label="新清單名稱",
        width=300,
        hint_text="留空則使用今日日期"
    )

    current_selected_list_text = ft.Text(
        "請選擇清單",
        size=16,
        weight="bold",
        color="blue",
        text_align=ft.TextAlign.CENTER
    )

    item_dropdown = ft.Dropdown(
        label="輸入/選擇",
        width=150,
        menu_width=220,
        menu_height=240,
        editable=True,
        enable_filter=True,
        enable_search=True,
        text_style=ft.TextStyle(size=12),
        label_style=ft.TextStyle(size=11),
        options=[],
    )

    selected_item_text = ft.Text(
        "目前項目：尚未輸入",
        size=12,
        text_align=ft.TextAlign.CENTER
    )

    main_qty_text = ft.Text(
        "1",
        size=18,
        weight="bold"
    )

    quick_items = []
    history_name_set = set()
    list_names_cache = []
    list_items_cache = {}

    QUICK_COLS = 3
    QUICK_ROWS = 10
    QUICK_TOTAL_SLOTS = QUICK_COLS * QUICK_ROWS
    QUICK_ITEM_LIMIT = QUICK_TOTAL_SLOTS - 1

    quick_grid = ft.Column(
        width=235,
        spacing=6,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    quick_new_input = ft.TextField(
        label="新增快捷項目",
        width=230
    )

    quick_edit_list = ft.Column(
        width=390,
        height=620,
        scroll=ft.ScrollMode.AUTO,
        spacing=6,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    home_screen = None
    item_screen = None
    quick_edit_screen = None

    def make_option(text):
        return ft.dropdown.Option(text)

    def make_unique_list_name(base_name, existing_names):
        final_name = base_name
        index = 1

        while final_name in existing_names:
            final_name = f"{base_name}({index})"
            index += 1

        return final_name

    def normalize_items(items_raw):
        if isinstance(items_raw, dict):
            return items_raw

        if isinstance(items_raw, list):
            return {
                str(i): v for i, v in enumerate(items_raw)
                if v and isinstance(v, dict)
            }

        return {}

    def get_item_dropdown_text():
        typed_text = str(getattr(item_dropdown, "text", "") or "").strip()
        selected_value = str(item_dropdown.value or "").strip()

        if typed_text:
            return typed_text

        return selected_value

    def clear_item_dropdown():
        item_dropdown.value = None

        try:
            item_dropdown.text = ""
        except Exception:
            pass

        selected_item_text.value = "目前項目：尚未輸入"

    def update_selected_item_text():
        item_name = get_item_dropdown_text()

        if item_name:
            selected_item_text.value = f"目前項目：{item_name}"
        else:
            selected_item_text.value = "目前項目：尚未輸入"

    def on_item_dropdown_text_change(e):
        update_selected_item_text()
        page.update()

    def on_item_dropdown_select(e):
        update_selected_item_text()
        page.update()

    def decrease_main_qty(e):
        try:
            qty = int(main_qty_text.value)
        except Exception:
            qty = 1

        if qty > 1:
            main_qty_text.value = str(qty - 1)

        page.update()

    def increase_main_qty(e):
        try:
            qty = int(main_qty_text.value)
        except Exception:
            qty = 1

        main_qty_text.value = str(qty + 1)
        page.update()

    if hasattr(item_dropdown, "on_text_change"):
        item_dropdown.on_text_change = on_item_dropdown_text_change

    if hasattr(item_dropdown, "on_select"):
        item_dropdown.on_select = on_item_dropdown_select

    if hasattr(item_dropdown, "on_change"):
        item_dropdown.on_change = on_item_dropdown_select

    def show_home_screen(e=None):
        home_screen.visible = True
        item_screen.visible = False
        quick_edit_screen.visible = False

        render_home_lists()
        page.update()

    def show_item_screen(list_name):
        current_list["name"] = list_name
        current_selected_list_text.value = list_name

        home_screen.visible = False
        item_screen.visible = True
        quick_edit_screen.visible = False

        render_items_from_cache(list_name)
        page.update()

    def show_quick_edit_screen(e=None):
        refresh_quick_edit_list()

        home_screen.visible = False
        item_screen.visible = False
        quick_edit_screen.visible = True

        page.update()

    def back_from_quick_edit(e=None):
        quick_edit_screen.visible = False

        if current_list["name"]:
            item_screen.visible = True
        else:
            home_screen.visible = True

        page.update()

    def get_unchecked_preview(list_name):
        items = list_items_cache.get(list_name, {})
        preview = []

        for _, item_data in items.items():
            if not isinstance(item_data, dict):
                continue

            if item_data.get("bought", False):
                continue

            name = item_data.get("name", "未命名")
            qty = item_data.get("qty", "1")

            preview.append(f"{name} x{qty}")

            if len(preview) >= 5:
                break

        return preview

    async def delete_home_list(list_name):
        if not list_name:
            return

        if list_name in list_names_cache:
            list_names_cache.remove(list_name)

        list_items_cache.pop(list_name, None)

        if current_list["name"] == list_name:
            current_list["name"] = None

        err_text.value = ""

        render_home_lists()
        page.update()

        page.run_task(delete_list_remote, list_name)

    def render_home_lists():
        home_list_view.controls.clear()

        if not list_names_cache:
            home_list_view.controls.append(
                ft.Text("目前沒有清單，請先新增清單", color="grey")
            )
            return

        for list_name in list_names_cache:
            preview = get_unchecked_preview(list_name)

            if preview:
                preview_text = "、".join(preview)
            else:
                preview_text = "沒有未完成項目"

            home_list_view.controls.append(
                ft.Container(
                    width=650,
                    padding=12,
                    border=ft.Border.all(1, "grey"),
                    border_radius=10,
                    content=ft.Row(
                        [
                            ft.Container(
                                expand=True,
                                padding=8,
                                on_click=lambda e, n=list_name: show_item_screen(n),
                                content=ft.Column(
                                    [
                                        ft.Text(
                                            list_name,
                                            size=18,
                                            weight="bold"
                                        ),
                                        ft.Text(
                                            preview_text,
                                            size=14,
                                            color="grey"
                                        )
                                    ],
                                    spacing=4
                                )
                            ),

                            ft.IconButton(
                                ft.Icons.DELETE_OUTLINE,
                                icon_color="red",
                                tooltip="刪除清單",
                                on_click=lambda e, n=list_name: page.run_task(delete_home_list, n)
                            )
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER
                    )
                )
            )

    def select_quick_item(item_name):
        item_dropdown.value = item_name

        try:
            item_dropdown.text = item_name
        except Exception:
            pass

        selected_item_text.value = f"目前項目：{item_name}"
        err_text.value = ""

        page.update()

    def refresh_quick_grid():
        quick_grid.controls.clear()

        slot_controls = []

        for i in range(QUICK_TOTAL_SLOTS):
            if i == QUICK_TOTAL_SLOTS - 1:
                slot_controls.append(
                    ft.Button(
                        "編輯",
                        width=72,
                        height=34,
                        style=ft.ButtonStyle(
                            text_style=ft.TextStyle(size=12)
                        ),
                        on_click=show_quick_edit_screen
                    )
                )
            elif i < len(quick_items):
                item_name = quick_items[i]

                slot_controls.append(
                    ft.Button(
                        item_name,
                        width=72,
                        height=34,
                        style=ft.ButtonStyle(
                            text_style=ft.TextStyle(size=12)
                        ),
                        on_click=lambda e, n=item_name: select_quick_item(n)
                    )
                )
            else:
                slot_controls.append(
                    ft.Container(
                        width=72,
                        height=34
                    )
                )

        for row_start in range(0, QUICK_TOTAL_SLOTS, QUICK_COLS):
            quick_grid.controls.append(
                ft.Row(
                    slot_controls[row_start:row_start + QUICK_COLS],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=4
                )
            )

    def refresh_quick_edit_list():
        quick_edit_list.controls.clear()

        if not quick_items:
            quick_edit_list.controls.append(
                ft.Text("目前沒有快捷項目", color="grey", size=12)
            )
            return

        for i, item_name in enumerate(quick_items):
            edit_field = ft.TextField(
                value=item_name,
                width=240,
                height=48,
                text_size=13,
                label=f"快捷 {i + 1}"
            )

            quick_edit_list.controls.append(
                ft.Container(
                    width=390,
                    padding=4,
                    content=ft.Row(
                        [
                            edit_field,

                            ft.Button(
                                "儲存",
                                width=70,
                                height=40,
                                on_click=lambda e, idx=i, field=edit_field:
                                    page.run_task(update_quick_item, idx, field.value)
                            ),

                            ft.IconButton(
                                ft.Icons.DELETE_OUTLINE,
                                icon_color="red",
                                icon_size=20,
                                tooltip="刪除快捷",
                                on_click=lambda e, idx=i:
                                    page.run_task(delete_quick_item, idx)
                            )
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=4
                    )
                )
            )

    def refresh_quick_ui():
        refresh_quick_grid()
        refresh_quick_edit_list()

    async def save_quick_items_remote():
        try:
            await request_json(
                "PUT",
                f"{DB_URL}/metadata/quick_items.json?auth={user_token['id']}",
                quick_items[:QUICK_ITEM_LIMIT]
            )

        except Exception as ex:
            err_text.value = f"❌ 快捷項目儲存失敗: {repr(ex)}"
            page.update()

    async def add_quick_item(e):
        name = (quick_new_input.value or "").strip()

        if not name:
            err_text.value = "❌ 請輸入快捷項目名稱"
            page.update()
            return

        if name in quick_items:
            err_text.value = "❌ 此快捷項目已存在"
            page.update()
            return

        if len(quick_items) >= QUICK_ITEM_LIMIT:
            err_text.value = f"❌ 快捷項目最多 {QUICK_ITEM_LIMIT} 個"
            page.update()
            return

        quick_items.append(name)
        quick_new_input.value = ""
        err_text.value = ""

        refresh_quick_ui()
        page.update()

        await save_quick_items_remote()

    async def update_quick_item(index, new_name):
        new_name = (new_name or "").strip()

        if not new_name:
            err_text.value = "❌ 快捷項目不可空白"
            page.update()
            return

        if index < 0 or index >= len(quick_items):
            return

        for i, old_name in enumerate(quick_items):
            if i != index and old_name == new_name:
                err_text.value = "❌ 此快捷項目已存在"
                page.update()
                return

        quick_items[index] = new_name
        err_text.value = ""

        refresh_quick_ui()
        page.update()

        await save_quick_items_remote()

    async def delete_quick_item(index):
        if index < 0 or index >= len(quick_items):
            return

        quick_items.pop(index)
        err_text.value = ""

        refresh_quick_ui()
        page.update()

        await save_quick_items_remote()

    def render_items_from_cache(list_name):
        items_view.controls.clear()

        items = list_items_cache.get(list_name, {})

        if not items:
            items_view.controls.append(
                ft.Text("此清單目前沒有項目", color="grey")
            )
        else:
            for item_id, item_data in items.items():
                if not isinstance(item_data, dict):
                    continue

                items_view.controls.append(
                    render_item_row(list_name, item_id, item_data)
                )

        page.update()

    def render_item_row(list_name, item_id, item_data):
        name = item_data.get("name", "未命名")
        qty = item_data.get("qty", "1")
        bought = item_data.get("bought", False)

        qty_text = ft.Text(
            f"{qty}",
            size=16,
            weight="bold"
        )

        async def checkbox_changed(e, i_id=item_id):
            new_value = e.control.value

            if list_name in list_items_cache and i_id in list_items_cache[list_name]:
                list_items_cache[list_name][i_id]["bought"] = new_value

            render_home_lists()

            try:
                await request_json(
                    "PATCH",
                    f"{DB_URL}/shopping_lists/{list_name}/{i_id}.json?auth={user_token['id']}",
                    {"bought": new_value}
                )

            except Exception as ex:
                e.control.value = not new_value

                if list_name in list_items_cache and i_id in list_items_cache[list_name]:
                    list_items_cache[list_name][i_id]["bought"] = not new_value

                render_home_lists()

                err_text.value = f"❌ 勾選更新失敗: {repr(ex)}"
                page.update()

        async def row_qty_change(e, delta, i_id=item_id, qty_control=qty_text):
            try:
                old_qty = int(qty_control.value)
            except Exception:
                old_qty = 1

            new_qty = old_qty + delta

            if new_qty < 1:
                new_qty = 1

            if new_qty == old_qty:
                return

            qty_control.value = str(new_qty)
            err_text.value = ""

            if list_name in list_items_cache and i_id in list_items_cache[list_name]:
                list_items_cache[list_name][i_id]["qty"] = str(new_qty)

            render_home_lists()
            page.update()

            try:
                await request_json(
                    "PATCH",
                    f"{DB_URL}/shopping_lists/{list_name}/{i_id}.json?auth={user_token['id']}",
                    {"qty": str(new_qty)}
                )

            except Exception as ex:
                qty_control.value = str(old_qty)

                if list_name in list_items_cache and i_id in list_items_cache[list_name]:
                    list_items_cache[list_name][i_id]["qty"] = str(old_qty)

                render_home_lists()

                err_text.value = f"❌ 數量更新失敗: {repr(ex)}"
                page.update()

        async def delete_item(e, i_id=item_id):
            backup_item = None

            if list_name in list_items_cache:
                backup_item = list_items_cache[list_name].pop(i_id, None)

            render_items_from_cache(list_name)
            render_home_lists()

            try:
                await request_json(
                    "DELETE",
                    f"{DB_URL}/shopping_lists/{list_name}/{i_id}.json?auth={user_token['id']}"
                )

            except Exception as ex:
                if backup_item is not None:
                    list_items_cache.setdefault(list_name, {})[i_id] = backup_item
                    render_items_from_cache(list_name)
                    render_home_lists()

                err_text.value = f"❌ 刪除項目失敗: {repr(ex)}"
                page.update()

        return ft.Container(
            width=330,
            padding=6,
            border=ft.Border.all(1, "grey"),
            border_radius=8,
            alignment=ft.Alignment.CENTER,
            content=ft.Row(
                [
                    ft.Checkbox(
                        value=bought,
                        on_change=lambda e, task=checkbox_changed:
                            page.run_task(task, e)
                    ),

                    ft.Text(
                        name,
                        size=14,
                        expand=True,
                        text_align=ft.TextAlign.CENTER
                    ),

                    ft.Row(
                        [
                            ft.IconButton(
                                ft.Icons.REMOVE_CIRCLE_OUTLINE,
                                tooltip="數量減少",
                                icon_size=18,
                                on_click=lambda e, d=-1, task=row_qty_change:
                                    page.run_task(task, e, d)
                            ),

                            qty_text,

                            ft.IconButton(
                                ft.Icons.ADD_CIRCLE_OUTLINE,
                                tooltip="數量增加",
                                icon_size=18,
                                on_click=lambda e, d=1, task=row_qty_change:
                                    page.run_task(task, e, d)
                            ),

                            ft.IconButton(
                                ft.Icons.DELETE_OUTLINE,
                                icon_color="red",
                                tooltip="刪除項目",
                                icon_size=18,
                                on_click=lambda e, task=delete_item:
                                    page.run_task(task, e)
                            )
                        ],
                        spacing=0
                    )
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                vertical_alignment=ft.CrossAxisAlignment.CENTER
            )
        )

    async def fetch_items(list_name, show_loading=False):
        if not list_name or list_name == "請選擇清單":
            page.update()
            return

        if show_loading:
            items_view.controls.clear()
            items_view.controls.append(
                ft.Text("載入中...", color="grey")
            )
            page.update()

        items_raw = await request_json(
            "GET",
            f"{DB_URL}/shopping_lists/{list_name}.json?auth={user_token['id']}"
        )

        list_items_cache[list_name] = normalize_items(items_raw)
        render_items_from_cache(list_name)
        render_home_lists()

    async def fetch_all_lists_items():
        async def fetch_one(list_name):
            try:
                items_raw = await request_json(
                    "GET",
                    f"{DB_URL}/shopping_lists/{list_name}.json?auth={user_token['id']}"
                )

                return list_name, normalize_items(items_raw)

            except Exception:
                return list_name, {}

        results = await asyncio.gather(
            *[fetch_one(name) for name in list_names_cache],
            return_exceptions=True
        )

        for result in results:
            if isinstance(result, Exception):
                continue

            list_name, items = result
            list_items_cache[list_name] = items

    async def add_list_click(e):
        try:
            raw_input = (list_name_input.value or "").strip()
            base_name = raw_input if raw_input else datetime.datetime.now().strftime("%Y-%m-%d")

            current_lists = await request_json(
                "GET",
                f"{DB_URL}/metadata/lists.json?auth={user_token['id']}"
            )

            if not isinstance(current_lists, dict):
                current_lists = {}

            final_name = make_unique_list_name(base_name, set(current_lists.keys()))

            await request_json(
                "PATCH",
                f"{DB_URL}/metadata/lists.json?auth={user_token['id']}",
                {final_name: True}
            )

            if final_name not in list_names_cache:
                list_names_cache.append(final_name)
                list_names_cache.sort(reverse=True)

            list_items_cache[final_name] = {}

            list_name_input.value = ""
            err_text.value = ""

            render_home_lists()
            show_item_screen(final_name)

        except Exception as ex:
            err_text.value = f"❌ 新增清單失敗: {repr(ex)}"
            page.update()

    async def delete_list_remote(list_name):
        try:
            await asyncio.gather(
                request_json(
                    "DELETE",
                    f"{DB_URL}/metadata/lists/{list_name}.json?auth={user_token['id']}"
                ),
                request_json(
                    "DELETE",
                    f"{DB_URL}/shopping_lists/{list_name}.json?auth={user_token['id']}"
                )
            )

        except Exception as ex:
            err_text.value = f"❌ 背景刪除清單失敗: {repr(ex)}"
            page.update()

    async def delete_current_list(e):
        list_name = current_list["name"]

        if not list_name:
            err_text.value = "❌ 目前沒有可刪除的清單"
            page.update()
            return

        if list_name in list_names_cache:
            list_names_cache.remove(list_name)

        list_items_cache.pop(list_name, None)

        current_list["name"] = None
        err_text.value = ""

        render_home_lists()
        show_home_screen()

        page.run_task(delete_list_remote, list_name)

    async def save_history_item(name):
        try:
            await request_json(
                "PATCH",
                f"{DB_URL}/metadata/history.json?auth={user_token['id']}",
                {name: {"active": True}}
            )

        except Exception as ex:
            print(f"歷史項目儲存失敗: {repr(ex)}")

    async def add_item_to_current_list(name, qty, clear_input=True):
        list_name = current_list["name"]

        if not list_name:
            err_text.value = "❌ 請先選擇清單"
            page.update()
            return

        if not name:
            err_text.value = "❌ 請輸入項目名稱"
            page.update()
            return

        try:
            new_item_data = {
                "name": name,
                "qty": qty,
                "bought": False
            }

            post_data = await request_json(
                "POST",
                f"{DB_URL}/shopping_lists/{list_name}.json?auth={user_token['id']}",
                new_item_data
            )

            if not isinstance(post_data, dict):
                await fetch_items(list_name, show_loading=True)
                return

            new_item_id = post_data.get("name")

            if not new_item_id:
                await fetch_items(list_name, show_loading=True)
                return

            list_items_cache.setdefault(list_name, {})[new_item_id] = new_item_data

            render_items_from_cache(list_name)
            render_home_lists()

            if name not in history_name_set:
                history_name_set.add(name)

                old_options = item_dropdown.options or []
                item_dropdown.options = [make_option(name)] + old_options

            if clear_input:
                clear_item_dropdown()
                main_qty_text.value = "1"

            err_text.value = ""
            page.update()

            page.run_task(save_history_item, name)

        except Exception as ex:
            err_text.value = f"❌ 新增項目失敗: {repr(ex)}"
            page.update()

    async def add_item_final(e):
        name = get_item_dropdown_text()
        qty = main_qty_text.value

        await add_item_to_current_list(name, qty, clear_input=True)

    async def delete_selected_history_item(e):
        history_name = get_item_dropdown_text()

        if not history_name:
            err_text.value = "❌ 請先選擇要刪除的歷史項目"
            page.update()
            return

        if history_name not in history_name_set:
            err_text.value = "❌ 這不是歷史項目，無法刪除"
            page.update()
            return

        try:
            await request_json(
                "DELETE",
                f"{DB_URL}/metadata/history/{history_name}.json?auth={user_token['id']}"
            )

            clear_item_dropdown()
            err_text.value = ""

            await load_metadata(selected_list=current_list["name"])

        except Exception as ex:
            err_text.value = f"❌ 刪除歷史項目失敗: {repr(ex)}"
            page.update()

    async def load_metadata(selected_list=None):
        meta = await request_json(
            "GET",
            f"{DB_URL}/metadata.json?auth={user_token['id']}"
        )

        if not isinstance(meta, dict):
            meta = {}

        lists_raw = meta.get("lists", {})
        if not isinstance(lists_raw, dict):
            lists_raw = {}

        list_names_cache.clear()
        list_names_cache.extend(sorted(lists_raw.keys(), reverse=True))

        history_raw = meta.get("history", {})
        if not isinstance(history_raw, dict):
            history_raw = {}

        history_keys = [
            h for h in history_raw.keys()
            if h not in ["True", "{'active': True}"]
        ]

        history_name_set.clear()
        history_name_set.update(history_keys)

        item_dropdown.options = [
            make_option(h)
            for h in reversed(history_keys[-100:])
        ]

        quick_raw = meta.get("quick_items", [])

        quick_items.clear()

        if isinstance(quick_raw, list):
            for q in quick_raw:
                if isinstance(q, str) and q.strip():
                    quick_items.append(q.strip())

        elif isinstance(quick_raw, dict):
            for q in quick_raw.keys():
                if isinstance(q, str) and q.strip():
                    quick_items.append(q.strip())

        del quick_items[QUICK_ITEM_LIMIT:]

        refresh_quick_ui()

        await fetch_all_lists_items()

        render_home_lists()

        if selected_list:
            show_item_screen(selected_list)
        else:
            show_home_screen()

    async def process_login(e):
        email = (email_in.value or "").strip()
        password = (pass_in.value or "").strip()

        if not email or not password:
            err_text.value = "❌ 請輸入帳號與密碼"
            page.update()
            return

        try:
            data = await request_json(
                "POST",
                AUTH_SIGNIN,
                {
                    "email": email,
                    "password": password,
                    "returnSecureToken": True
                }
            )

            if not isinstance(data, dict) or "localId" not in data:
                error_message = ""

                if isinstance(data, dict):
                    error_message = data.get("error", {}).get("message", "")

                err_text.value = f"❌ 帳密錯誤: {error_message}"
                page.update()
                return

            uid = data["localId"]
            user_token["id"] = data.get("idToken")

            user_data = await request_json(
                "GET",
                f"{DB_URL}/users/{uid}.json?auth={user_token['id']}"
            )

            if isinstance(user_data, dict) and user_data.get("is_approved"):
                await prefs.set("shopping_email", email)
                await prefs.set("shopping_password", password)

                login_container.visible = False
                shopping_container.visible = True
                err_text.value = ""

                await load_metadata()

            else:
                err_text.value = "⏳ 尚未通過審核"
                page.update()

        except Exception as e:
            err_text.value = f"❌ 連線失敗: {repr(e)}"
            page.update()

    async def process_register(e):
        email = (email_in.value or "").strip()
        password = (pass_in.value or "").strip()

        if not email or not password:
            err_text.value = "❌ 請輸入帳號與密碼"
            page.update()
            return

        try:
            auth_data = await request_json(
                "POST",
                AUTH_SIGNUP,
                {
                    "email": email,
                    "password": password,
                    "returnSecureToken": True
                }
            )

            if isinstance(auth_data, dict) and "localId" in auth_data:
                uid = auth_data["localId"]
                temp_token = auth_data.get("idToken")

                await request_json(
                    "PUT",
                    f"{DB_URL}/users/{uid}.json?auth={temp_token}",
                    {
                        "email": email,
                        "is_approved": False
                    }
                )

                err_text.value = "✅ 註冊成功，請聯繫管理員"
                page.update()

            else:
                error_message = ""

                if isinstance(auth_data, dict):
                    error_message = auth_data.get("error", {}).get("message", "")

                err_text.value = f"❌ 註冊失敗: {error_message}"
                page.update()

        except Exception as e:
            err_text.value = f"❌ 註冊失敗: {repr(e)}"
            page.update()

    home_screen = ft.Column(
        visible=True,
        width=700,
        height=820,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=10,
        controls=[
            ft.Text("清單總覽", size=24, weight="bold"),

            ft.Row(
                [
                    list_name_input,
                    ft.IconButton(
                        ft.Icons.ADD_BOX,
                        icon_color="green",
                        tooltip="新增清單",
                        on_click=add_list_click
                    )
                ],
                alignment=ft.MainAxisAlignment.CENTER
            ),

            err_text,

            home_list_view
        ]
    )

    quick_section = ft.Container(
        width=235,
        padding=8,
        border=ft.Border.all(1, "grey"),
        border_radius=10,
        content=ft.Column(
            [
                ft.Text("快捷項目", size=16, weight="bold"),
                quick_grid
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=8
        )
    )

    item_add_section = ft.Container(
        width=220,
        padding=8,
        border=ft.Border.all(1, "grey"),
        border_radius=10,
        content=ft.Column(
            [
                ft.Text("新增項目", size=16, weight="bold"),

                ft.Row(
                    [
                        item_dropdown,

                        ft.IconButton(
                            ft.Icons.DELETE_OUTLINE,
                            icon_color="red",
                            tooltip="刪除目前選到的歷史項目",
                            on_click=lambda e: page.run_task(delete_selected_history_item, e)
                        )
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=0
                ),

                selected_item_text,

                ft.Row(
                    [
                        ft.IconButton(
                            ft.Icons.REMOVE_CIRCLE_OUTLINE,
                            on_click=decrease_main_qty
                        ),
                        main_qty_text,
                        ft.IconButton(
                            ft.Icons.ADD_CIRCLE_OUTLINE,
                            on_click=increase_main_qty
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=0
                ),

                ft.Button(
                    "➕ 加入",
                    on_click=add_item_final,
                    width=160,
                    bgcolor="blue",
                    color="white"
                )
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=6
        )
    )

    left_panel = ft.Container(
        width=360,
        height=760,
        padding=8,
        border=ft.Border.all(1, "grey"),
        border_radius=10,
        content=ft.Column(
            [
                ft.Row(
                    [
                        ft.Button(
                            "← 返回",
                            width=120,
                            on_click=show_home_screen
                        ),

                        ft.IconButton(
                            ft.Icons.DELETE_OUTLINE,
                            icon_color="red",
                            tooltip="刪除目前清單",
                            on_click=lambda e: page.run_task(delete_current_list, e)
                        )
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),

                ft.Container(
                    width=330,
                    alignment=ft.Alignment.CENTER,
                    content=current_selected_list_text
                ),

                ft.Divider(),

                items_view
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=6
        )
    )

    right_sidebar = ft.Container(
        width=235,
        height=760,
        padding=8,
        border=ft.Border.all(1, "grey"),
        border_radius=10,
        content=ft.Column(
            [
                quick_section,
                item_add_section
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10
        )
    )

    item_screen = ft.Row(
        visible=False,
        width=620,
        height=None,
        alignment=ft.MainAxisAlignment.CENTER,
        vertical_alignment=ft.CrossAxisAlignment.START,
        spacing=8,
        wrap=True,
        run_spacing=8,
        controls=[
            left_panel,
            right_sidebar
        ]
    )

    quick_edit_screen = ft.Column(
        visible=False,
        width=700,
        height=820,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=12,
        controls=[
            ft.Row(
                [
                    ft.Button(
                        "← 返回",
                        width=100,
                        on_click=back_from_quick_edit
                    )
                ],
                alignment=ft.MainAxisAlignment.START
            ),

            ft.Text("編輯快捷項目", size=20, weight="bold"),

            ft.Container(
                width=420,
                height=700,
                padding=10,
                border=ft.Border.all(1, "grey"),
                border_radius=10,
                content=ft.Column(
                    [
                        ft.Row(
                            [
                                quick_new_input,
                                ft.Button(
                                    "新增",
                                    width=80,
                                    on_click=lambda e: page.run_task(add_quick_item, e)
                                )
                            ],
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=6
                        ),

                        quick_edit_list
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=8
                )
            )
        ]
    )

    shopping_container.controls = [
        home_screen,
        item_screen,
        quick_edit_screen
    ]

    def apply_responsive_layout(e=None):
        screen_width = page.width or page.window_width or 720
        is_mobile = screen_width < 650

        if is_mobile:
            page.scroll = ft.ScrollMode.AUTO

            shopping_container.width = screen_width - 16
            shopping_container.height = None

            home_screen.width = screen_width - 16
            home_screen.height = None
            home_list_view.width = screen_width - 24
            home_list_view.height = 520

            item_screen.width = screen_width - 16
            item_screen.height = None

            # 手機版：快捷項目和新增項目放在上方，清單項目放下方
            item_screen.controls = [
                right_sidebar,
                left_panel
            ]

            right_sidebar.width = screen_width - 24
            right_sidebar.height = None

            quick_section.width = min(300, screen_width - 36)
            item_add_section.width = min(300, screen_width - 36)

            left_panel.width = screen_width - 24
            left_panel.height = None

            items_view.width = screen_width - 40
            items_view.height = 420

        else:
            page.scroll = ft.ScrollMode.AUTO

            shopping_container.width = 700
            shopping_container.height = 820

            home_screen.width = 700
            home_screen.height = 820
            home_list_view.width = 660
            home_list_view.height = 640

            item_screen.width = 620
            item_screen.height = 800

            # 桌機版：左邊清單，右邊快捷項目
            item_screen.controls = [
                left_panel,
                right_sidebar
            ]

            left_panel.width = 360
            left_panel.height = 760

            right_sidebar.width = 235
            right_sidebar.height = 760

            quick_section.width = 235
            item_add_section.width = 220

            items_view.width = 340
            items_view.height = 650

        page.update()


    page.on_resize = apply_responsive_layout


    login_container = ft.Column(
        [
            ft.Text("荳比小窩購物清單", size=25, weight="bold"),
            email_in := ft.TextField(label="Email", width=300),
            pass_in := ft.TextField(label="密碼", password=True, width=300),
            ft.Button("登入", on_click=process_login, width=300),
            ft.Button("註冊", on_click=process_register, width=300),
            err_text
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        alignment=ft.MainAxisAlignment.CENTER
    )

    page.add(login_container, shopping_container)
    apply_responsive_layout()
    
    refresh_quick_ui()

    async def auto_login():
        await asyncio.sleep(0.5)

        try:
            has_email = await prefs.contains_key("shopping_email")
            has_password = await prefs.contains_key("shopping_password")

            if not has_email or not has_password:
                return

            saved_email = await prefs.get("shopping_email")
            saved_password = await prefs.get("shopping_password")

            if not saved_email or not saved_password:
                return

            email_in.value = saved_email
            pass_in.value = saved_password
            page.update()

            print(f"自動登入帳號: {saved_email}")

            await process_login(None)

        except Exception as e:
            print(f"自動登入失敗: {repr(e)}")

    page.run_task(auto_login)


if __name__ == "__main__":
    ft.run(main)