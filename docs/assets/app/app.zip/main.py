import flet as ft
import httpx
import datetime
import asyncio
import json

# --- 1. Firebase 配置 ---
PROJECT_ID = "ourshoppinglist-7e6c7"
API_KEY = "AIzaSyC5hpB-l_gLAAvH5hTDVobcHxu2x6Gju4I"
DB_URL = f"https://{PROJECT_ID}-default-rtdb.firebaseio.com"
AUTH_SIGNIN = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={API_KEY}"
AUTH_SIGNUP = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={API_KEY}"


def is_web_runtime():
    try:
        import pyodide  # noqa
        return True
    except Exception:
        return False


async def request_json(method, url, payload=None):
    method = method.upper()

    if is_web_runtime():
        from pyodide.http import pyfetch

        headers = {
            "Content-Type": "application/json"
        }

        kwargs = {
            "method": method,
            "headers": headers
        }

        if payload is not None and method not in ["GET", "DELETE"]:
            kwargs["body"] = json.dumps(payload)

        response = await pyfetch(url, **kwargs)
        text = await response.string()

        if not text:
            return {}

        try:
            return json.loads(text)
        except Exception:
            return {
                "raw": text,
                "status": response.status
            }

    async with httpx.AsyncClient(
        headers={
            "Accept-Encoding": "identity",
            "Content-Type": "application/json"
        },
        timeout=20.0
    ) as client:
        if method == "GET":
            response = await client.get(url)
        elif method == "POST":
            response = await client.post(url, json=payload)
        elif method == "PUT":
            response = await client.put(url, json=payload)
        elif method == "PATCH":
            response = await client.patch(url, json=payload)
        elif method == "DELETE":
            response = await client.delete(url)
        else:
            raise ValueError(f"Unsupported method: {method}")

        if not response.text:
            return {}

        return response.json()


async def main(page: ft.Page):
    page.title = "荳比小窩購物清單"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.window_width = 720
    page.window_height = 850
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.scroll = ft.ScrollMode.AUTO
    page.padding = 0

    user_token = {"id": None}
    prefs = ft.SharedPreferences()

    current_list = {"name": None}
    is_mobile_layout = {"value": False}

    err_text = ft.Text(color="red")

    shopping_container = ft.Column(
        visible=False,
        width=700,
        height=820,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=8
    )

    home_list_view = ft.Column(
        scroll=ft.ScrollMode.AUTO,
        height=640,
        width=660,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=8
    )

    items_view = ft.Column(
        scroll=ft.ScrollMode.AUTO,
        height=650,
        width=340,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=6
    )

    list_name_input = ft.TextField(
        label="新清單名稱",
        width=300,
        hint_text="留空則使用今日日期"
    )

    current_selected_list_text = ft.Text(
        "請選擇清單",
        size=16,
        weight="bold",
        color="blue",
        text_align=ft.TextAlign.CENTER
    )

    item_dropdown = ft.Dropdown(
        label="輸入/選擇",
        width=150,
        menu_width=220,
        menu_height=240,
        editable=True,
        enable_filter=True,
        enable_search=True,
        text_style=ft.TextStyle(size=12),
        label_style=ft.TextStyle(size=11),
        options=[],
    )

    selected_item_text = ft.Text(
        "目前項目：尚未輸入",
        size=12,
        text_align=ft.TextAlign.CENTER
    )

    main_qty_text = ft.Text(
        "1",
        size=18,
        weight="bold"
    )

    quick_items = []
    history_name_set = set()
    list_names_cache = []
    list_items_cache = {}

    QUICK_COLS = 3
    QUICK_ROWS = 10
    QUICK_TOTAL_SLOTS = QUICK_COLS * QUICK_ROWS
    QUICK_ITEM_LIMIT = QUICK_TOTAL_SLOTS - 1
    QUICK_NAME_MAX_LEN = 10

    quick_grid = ft.Column(
        width=235,
        height=260,
        scroll=ft.ScrollMode.AUTO,
        spacing=6,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    quick_new_input = ft.TextField(
        label="新增快捷項目",
        width=200,
        height=44,
        text_size=12,
        label_style=ft.TextStyle(size=11),
        max_length=QUICK_NAME_MAX_LEN
    )

    quick_edit_list = ft.Column(
        width=360,
        height=620,
        scroll=ft.ScrollMode.AUTO,
        spacing=4,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )

    add_item_button = ft.Button(
        "➕ 加入",
        on_click=None,
        width=160,
        height=36,
        bgcolor="blue",
        color="white"
    )

    home_screen = None
    item_screen = None
    quick_edit_screen = None
    current_list_name_container = None
    left_panel = None
    right_sidebar = None
    quick_section = None
    item_add_section = None

    def make_option(text):
        return ft.dropdown.Option(text)

    def make_unique_list_name(base_name, existing_names):
        final_name = base_name
        index = 1

        while final_name in existing_names:
            final_name = f"{base_name}({index})"
            index += 1

        return final_name

    def normalize_items(items_raw):
        if isinstance(items_raw, dict):
            return items_raw

        if isinstance(items_raw, list):
            return {
                str(i): v for i, v in enumerate(items_raw)
                if v and isinstance(v, dict)
            }

        return {}

    def sorted_item_entries(items):
        if not isinstance(items, dict):
            return []

        entries = [
            (item_id, item_data)
            for item_id, item_data in items.items()
            if isinstance(item_data, dict)
        ]

        return sorted(
            entries,
            key=lambda x: str(x[1].get("created_at", "")),
            reverse=True
        )

    def get_item_dropdown_text():
        typed_text = str(getattr(item_dropdown, "text", "") or "").strip()
        selected_value = str(item_dropdown.value or "").strip()

        if typed_text:
            return typed_text

        return selected_value

    def clear_item_dropdown():
        item_dropdown.value = None

        try:
            item_dropdown.text = ""
        except Exception:
            pass

        selected_item_text.value = "目前項目：尚未輸入"

    def update_selected_item_text():
        item_name = get_item_dropdown_text()

        if item_name:
            selected_item_text.value = f"目前項目：{item_name}"
        else:
            selected_item_text.value = "目前項目：尚未輸入"

    def on_item_dropdown_text_change(e):
        update_selected_item_text()
        page.update()

    def on_item_dropdown_select(e):
        update_selected_item_text()
        page.update()

    def decrease_main_qty(e):
        try:
            qty = int(main_qty_text.value)
        except Exception:
            qty = 1

        if qty > 1:
            main_qty_text.value = str(qty - 1)

        page.update()

    def increase_main_qty(e):
        try:
            qty = int(main_qty_text.value)
        except Exception:
            qty = 1

        main_qty_text.value = str(qty + 1)
        page.update()

    if hasattr(item_dropdown, "on_text_change"):
        item_dropdown.on_text_change = on_item_dropdown_text_change

    if hasattr(item_dropdown, "on_select"):
        item_dropdown.on_select = on_item_dropdown_select

    if hasattr(item_dropdown, "on_change"):
        item_dropdown.on_change = on_item_dropdown_select

    def scroll_items_to_top():
        try:
            items_view.scroll_to(offset=0, duration=250)
        except Exception:
            pass

    def show_home_screen(e=None):
        home_screen.visible = True
        item_screen.visible = False
        quick_edit_screen.visible = False

        render_home_lists()
        page.update()

    def show_item_screen(list_name):
        current_list["name"] = list_name
        current_selected_list_text.value = list_name

        home_screen.visible = False
        item_screen.visible = True
        quick_edit_screen.visible = False

        if list_name in list_items_cache:
            render_items_from_cache(list_name)
            page.update()
        else:
            items_view.controls.clear()
            items_view.controls.append(
                ft.Text("載入中...", color="grey")
            )
            page.update()
            page.run_task(fetch_items, list_name, True)

    def show_quick_edit_screen(e=None):
        refresh_quick_edit_list()

        home_screen.visible = False
        item_screen.visible = False
        quick_edit_screen.visible = True

        page.update()

    def back_from_quick_edit(e=None):
        quick_edit_screen.visible = False

        if current_list["name"]:
            item_screen.visible = True
        else:
            home_screen.visible = True

        page.update()

    def get_unchecked_preview(list_name):
        if list_name not in list_items_cache:
            return None

        items = list_items_cache.get(list_name, {})
        preview = []

        for _, item_data in sorted_item_entries(items):
            if item_data.get("bought", False):
                continue

            name = item_data.get("name", "未命名")
            qty = item_data.get("qty", "1")

            preview.append(f"{name} x{qty}")

            if len(preview) >= 5:
                break

        return preview

    async def delete_home_list(list_name):
        if not list_name:
            return

        if list_name in list_names_cache:
            list_names_cache.remove(list_name)

        list_items_cache.pop(list_name, None)

        if current_list["name"] == list_name:
            current_list["name"] = None

        err_text.value = ""

        render_home_lists()
        page.update()

        page.run_task(delete_list_remote, list_name)

    def render_home_lists():
        home_list_view.controls.clear()

        if not list_names_cache:
            home_list_view.controls.append(
                ft.Text("目前沒有清單，請先新增清單", color="grey")
            )
            return

        card_width = min(650, int((home_list_view.width or 660) - 10))

        for list_name in list_names_cache:
            preview = get_unchecked_preview(list_name)

            if preview is None:
                preview_text = "點擊進入查看項目"
            elif preview:
                preview_text = "、".join(preview)
            else:
                preview_text = "沒有未完成項目"

            home_list_view.controls.append(
                ft.Container(
                    width=card_width,
                    padding=12,
                    border=ft.Border.all(1, "grey"),
                    border_radius=10,
                    content=ft.Row(
                        [
                            ft.Container(
                                expand=True,
                                padding=8,
                                on_click=lambda e, n=list_name: show_item_screen(n),
                                content=ft.Column(
                                    [
                                        ft.Text(
                                            list_name,
                                            size=18,
                                            weight="bold"
                                        ),
                                        ft.Text(
                                            preview_text,
                                            size=14,
                                            color="grey"
                                        )
                                    ],
                                    spacing=4
                                )
                            ),

                            ft.IconButton(
                                ft.Icons.DELETE_OUTLINE,
                                icon_color="red",
                                tooltip="刪除清單",
                                on_click=lambda e, n=list_name: page.run_task(delete_home_list, n)
                            )
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER
                    )
                )
            )

    def select_quick_item(item_name):
        item_dropdown.value = item_name

        try:
            item_dropdown.text = item_name
        except Exception:
            pass

        selected_item_text.value = f"目前項目：{item_name}"
        err_text.value = ""

        page.update()

    def get_quick_display_text(text):
        text = str(text or "").strip()

        if len(text) > QUICK_NAME_MAX_LEN:
            return text[:QUICK_NAME_MAX_LEN]

        return text

    def get_quick_visual_len(text):
        total = 0.0

        for ch in str(text or ""):
            # Chinese / full-width characters need more horizontal space than ASCII.
            total += 1.6 if ord(ch) > 127 else 1.0

        return max(1.0, total)

    def get_quick_font_size(text, btn_width, base_size):
        display_text = get_quick_display_text(text)
        usable_width = max(8, int(btn_width) - 6)
        visual_len = get_quick_visual_len(display_text)

        # Estimate a font size that keeps the text inside the button.
        estimated_size = int(usable_width / (visual_len * 0.56))

        return max(4, min(base_size, estimated_size))

    def make_quick_button(text, btn_width, btn_height, base_font_size, on_click):
        display_text = get_quick_display_text(text)

        return ft.Container(
            width=btn_width,
            height=btn_height,
            padding=1,
            alignment=ft.Alignment.CENTER,
            border=ft.Border.all(1, "#BDBDBD"),
            border_radius=6,
            bgcolor="#F7F7F7",
            on_click=on_click,
            content=ft.Text(
                display_text,
                size=get_quick_font_size(display_text, btn_width, base_font_size),
                text_align=ft.TextAlign.CENTER,
                max_lines=1
            )
        )

    def refresh_quick_grid():
        quick_grid.controls.clear()

        if is_mobile_layout["value"]:
            grid_width = int(quick_grid.width or 130)
            row_spacing = 2

            # Auto-fit 3 columns inside the current mobile sidebar width.
            btn_width = int((grid_width - row_spacing * (QUICK_COLS - 1) - 4) / QUICK_COLS)
            btn_width = max(34, btn_width)

            btn_height = 28 if btn_width < 39 else 30
            font_size = 8 if btn_width < 39 else 9
            empty_width = btn_width
        else:
            btn_width = 68
            btn_height = 32
            font_size = 11
            empty_width = 68
            row_spacing = 3

        slot_controls = []

        for i in range(QUICK_TOTAL_SLOTS):
            if i == QUICK_TOTAL_SLOTS - 1:
                slot_controls.append(
                    make_quick_button(
                        "編輯",
                        btn_width,
                        btn_height,
                        font_size,
                        show_quick_edit_screen
                    )
                )
            elif i < len(quick_items):
                item_name = quick_items[i]

                slot_controls.append(
                    make_quick_button(
                        item_name,
                        btn_width,
                        btn_height,
                        font_size,
                        lambda e, n=item_name: select_quick_item(n)
                    )
                )
            else:
                slot_controls.append(
                    ft.Container(
                        width=empty_width,
                        height=btn_height
                    )
                )

        for row_start in range(0, QUICK_TOTAL_SLOTS, QUICK_COLS):
            quick_grid.controls.append(
                ft.Row(
                    slot_controls[row_start:row_start + QUICK_COLS],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=row_spacing
                )
            )

    def refresh_quick_edit_list():
        quick_edit_list.controls.clear()

        if not quick_items:
            quick_edit_list.controls.append(
                ft.Text("目前沒有快捷項目", color="grey", size=12)
            )
            return

        if is_mobile_layout["value"]:
            row_width = int((quick_edit_list.width or 300) - 2)
            row_width = max(210, row_width)

            btn_width = 52
            icon_size = 18
            icon_width = 30

            # Field width follows the available row width, so narrow phones will not cut the right side.
            field_width = row_width - btn_width - icon_width - 18
            field_width = max(120, field_width)
        else:
            row_width = 350
            field_width = 205
            btn_width = 58
            icon_size = 19

        for i, item_name in enumerate(quick_items):
            edit_field = ft.TextField(
                value=item_name,
                width=field_width,
                height=42,
                text_size=12,
                label=f"快捷 {i + 1}",
                label_style=ft.TextStyle(size=10),
                max_length=QUICK_NAME_MAX_LEN
            )

            quick_edit_list.controls.append(
                ft.Container(
                    width=row_width,
                    padding=2,
                    content=ft.Row(
                        [
                            edit_field,

                            ft.Button(
                                "儲存",
                                width=btn_width,
                                height=34,
                                style=ft.ButtonStyle(
                                    text_style=ft.TextStyle(size=11)
                                ),
                                on_click=lambda e, idx=i, field=edit_field:
                                    page.run_task(update_quick_item, idx, field.value)
                            ),

                            ft.IconButton(
                                ft.Icons.DELETE_OUTLINE,
                                icon_color="red",
                                icon_size=icon_size,
                                width=32,
                                height=32,
                                tooltip="刪除快捷",
                                on_click=lambda e, idx=i:
                                    page.run_task(delete_quick_item, idx)
                            )
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=3
                    )
                )
            )

    def refresh_quick_ui():
        refresh_quick_grid()
        refresh_quick_edit_list()

    async def save_quick_items_remote():
        try:
            await request_json(
                "PUT",
                f"{DB_URL}/metadata/quick_items.json?auth={user_token['id']}",
                quick_items[:QUICK_ITEM_LIMIT]
            )

        except Exception as ex:
            err_text.value = f"❌ 快捷項目儲存失敗: {repr(ex)}"
            page.update()

    async def add_quick_item(e):
        name = (quick_new_input.value or "").strip()

        if not name:
            err_text.value = "❌ 請輸入快捷項目名稱"
            page.update()
            return

        if len(name) > QUICK_NAME_MAX_LEN:
            err_text.value = f"❌ 快捷項目最多 {QUICK_NAME_MAX_LEN} 個字"
            page.update()
            return

        if name in quick_items:
            err_text.value = "❌ 此快捷項目已存在"
            page.update()
            return

        if len(quick_items) >= QUICK_ITEM_LIMIT:
            err_text.value = f"❌ 快捷項目最多 {QUICK_ITEM_LIMIT} 個"
            page.update()
            return

        quick_items.append(name)
        quick_new_input.value = ""
        err_text.value = ""

        refresh_quick_ui()
        page.update()

        await save_quick_items_remote()

    async def update_quick_item(index, new_name):
        new_name = (new_name or "").strip()

        if not new_name:
            err_text.value = "❌ 快捷項目不可空白"
            page.update()
            return

        if len(new_name) > QUICK_NAME_MAX_LEN:
            err_text.value = f"❌ 快捷項目最多 {QUICK_NAME_MAX_LEN} 個字"
            page.update()
            return

        if index < 0 or index >= len(quick_items):
            return

        for i, old_name in enumerate(quick_items):
            if i != index and old_name == new_name:
                err_text.value = "❌ 此快捷項目已存在"
                page.update()
                return

        quick_items[index] = new_name
        err_text.value = ""

        refresh_quick_ui()
        page.update()

        await save_quick_items_remote()

    async def delete_quick_item(index):
        if index < 0 or index >= len(quick_items):
            return

        quick_items.pop(index)
        err_text.value = ""

        refresh_quick_ui()
        page.update()

        await save_quick_items_remote()

    def render_items_from_cache(list_name):
        items_view.controls.clear()

        items = list_items_cache.get(list_name, {})

        if not items:
            items_view.controls.append(
                ft.Text("此清單目前沒有項目", color="grey")
            )
        else:
            for item_id, item_data in sorted_item_entries(items):
                items_view.controls.append(
                    render_item_row(list_name, item_id, item_data)
                )

        page.update()

    def render_item_row(list_name, item_id, item_data):
        name = item_data.get("name", "未命名")
        qty = item_data.get("qty", "1")
        bought = item_data.get("bought", False)

        qty_text = ft.Text(
            f"{qty}",
            size=16,
            weight="bold"
        )

        async def checkbox_changed(e, i_id=item_id):
            new_value = e.control.value

            if list_name in list_items_cache and i_id in list_items_cache[list_name]:
                list_items_cache[list_name][i_id]["bought"] = new_value

            try:
                await request_json(
                    "PATCH",
                    f"{DB_URL}/shopping_lists/{list_name}/{i_id}.json?auth={user_token['id']}",
                    {"bought": new_value}
                )

            except Exception as ex:
                e.control.value = not new_value

                if list_name in list_items_cache and i_id in list_items_cache[list_name]:
                    list_items_cache[list_name][i_id]["bought"] = not new_value

                err_text.value = f"❌ 勾選更新失敗: {repr(ex)}"
                page.update()

        async def row_qty_change(e, delta, i_id=item_id, qty_control=qty_text):
            try:
                old_qty = int(qty_control.value)
            except Exception:
                old_qty = 1

            new_qty = old_qty + delta

            if new_qty < 1:
                new_qty = 1

            if new_qty == old_qty:
                return

            qty_control.value = str(new_qty)
            err_text.value = ""

            if list_name in list_items_cache and i_id in list_items_cache[list_name]:
                list_items_cache[list_name][i_id]["qty"] = str(new_qty)

            page.update()

            try:
                await request_json(
                    "PATCH",
                    f"{DB_URL}/shopping_lists/{list_name}/{i_id}.json?auth={user_token['id']}",
                    {"qty": str(new_qty)}
                )

            except Exception as ex:
                qty_control.value = str(old_qty)

                if list_name in list_items_cache and i_id in list_items_cache[list_name]:
                    list_items_cache[list_name][i_id]["qty"] = str(old_qty)

                err_text.value = f"❌ 數量更新失敗: {repr(ex)}"
                page.update()

        async def delete_item(e, i_id=item_id):
            backup_item = None
            backup_index = None

            if list_name in list_items_cache:
                old_keys = list(list_items_cache[list_name].keys())
                if i_id in old_keys:
                    backup_index = old_keys.index(i_id)

                backup_item = list_items_cache[list_name].pop(i_id, None)

            for idx, ctrl in enumerate(list(items_view.controls)):
                if getattr(ctrl, "data", None) == i_id:
                    items_view.controls.pop(idx)
                    break

            if not items_view.controls:
                items_view.controls.append(
                    ft.Text("此清單目前沒有項目", color="grey")
                )

            page.update()

            try:
                await request_json(
                    "DELETE",
                    f"{DB_URL}/shopping_lists/{list_name}/{i_id}.json?auth={user_token['id']}"
                )

            except Exception as ex:
                if backup_item is not None:
                    restored_items = {}
                    old_items = list_items_cache.get(list_name, {})

                    if backup_index is None:
                        restored_items = {
                            i_id: backup_item,
                            **old_items
                        }
                    else:
                        keys = list(old_items.keys())

                        for k_index, key in enumerate(keys):
                            if k_index == backup_index:
                                restored_items[i_id] = backup_item
                            restored_items[key] = old_items[key]

                        if i_id not in restored_items:
                            restored_items[i_id] = backup_item

                    list_items_cache[list_name] = restored_items
                    render_items_from_cache(list_name)

                err_text.value = f"❌ 刪除項目失敗: {repr(ex)}"
                page.update()

        card_width = items_view.width or 330

        if is_mobile_layout["value"]:
            return ft.Container(
                data=item_id,
                width=card_width,
                padding=6,
                border=ft.Border.all(1, "grey"),
                border_radius=8,
                alignment=ft.Alignment.CENTER,
                content=ft.Column(
                    [
                        ft.Row(
                            [
                                ft.Checkbox(
                                    value=bought,
                                    on_change=lambda e, task=checkbox_changed:
                                        page.run_task(task, e)
                                ),

                                ft.Text(
                                    name,
                                    size=14,
                                    expand=True,
                                    text_align=ft.TextAlign.LEFT
                                ),
                            ],
                            alignment=ft.MainAxisAlignment.START,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER
                        ),

                        ft.Row(
                            [
                                ft.IconButton(
                                    ft.Icons.REMOVE_CIRCLE_OUTLINE,
                                    tooltip="數量減少",
                                    icon_size=18,
                                    width=30,
                                    height=30,
                                    on_click=lambda e, d=-1, task=row_qty_change:
                                        page.run_task(task, e, d)
                                ),

                                qty_text,

                                ft.IconButton(
                                    ft.Icons.ADD_CIRCLE_OUTLINE,
                                    tooltip="數量增加",
                                    icon_size=18,
                                    width=30,
                                    height=30,
                                    on_click=lambda e, d=1, task=row_qty_change:
                                        page.run_task(task, e, d)
                                ),

                                ft.Container(expand=True),

                                ft.IconButton(
                                    ft.Icons.DELETE_OUTLINE,
                                    icon_color="red",
                                    tooltip="刪除項目",
                                    icon_size=18,
                                    width=30,
                                    height=30,
                                    on_click=lambda e, task=delete_item:
                                        page.run_task(task, e)
                                )
                            ],
                            alignment=ft.MainAxisAlignment.START,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                            spacing=0
                        )
                    ],
                    spacing=0,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                )
            )

        return ft.Container(
            data=item_id,
            width=card_width,
            padding=6,
            border=ft.Border.all(1, "grey"),
            border_radius=8,
            alignment=ft.Alignment.CENTER,
            content=ft.Row(
                [
                    ft.Checkbox(
                        value=bought,
                        on_change=lambda e, task=checkbox_changed:
                            page.run_task(task, e)
                    ),

                    ft.Text(
                        name,
                        size=14,
                        expand=True,
                        text_align=ft.TextAlign.CENTER
                    ),

                    ft.IconButton(
                        ft.Icons.REMOVE_CIRCLE_OUTLINE,
                        tooltip="數量減少",
                        icon_size=18,
                        on_click=lambda e, d=-1, task=row_qty_change:
                            page.run_task(task, e, d)
                    ),

                    qty_text,

                    ft.IconButton(
                        ft.Icons.ADD_CIRCLE_OUTLINE,
                        tooltip="數量增加",
                        icon_size=18,
                        on_click=lambda e, d=1, task=row_qty_change:
                            page.run_task(task, e, d)
                    ),

                    ft.IconButton(
                        ft.Icons.DELETE_OUTLINE,
                        icon_color="red",
                        tooltip="刪除項目",
                        icon_size=18,
                        on_click=lambda e, task=delete_item:
                            page.run_task(task, e)
                    )
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                vertical_alignment=ft.CrossAxisAlignment.CENTER
            )
        )

    async def fetch_items(list_name, show_loading=False):
        if not list_name or list_name == "請選擇清單":
            page.update()
            return

        if show_loading:
            items_view.controls.clear()
            items_view.controls.append(
                ft.Text("載入中...", color="grey")
            )
            page.update()

        items_raw = await request_json(
            "GET",
            f"{DB_URL}/shopping_lists/{list_name}.json?auth={user_token['id']}"
        )

        list_items_cache[list_name] = normalize_items(items_raw)
        render_items_from_cache(list_name)
        scroll_items_to_top()

    async def fetch_all_lists_items():
        # 保留函式，但登入時不主動呼叫，以避免手機版登入後一次抓太多資料。
        async def fetch_one(list_name):
            try:
                items_raw = await request_json(
                    "GET",
                    f"{DB_URL}/shopping_lists/{list_name}.json?auth={user_token['id']}"
                )

                return list_name, normalize_items(items_raw)

            except Exception:
                return list_name, {}

        results = await asyncio.gather(
            *[fetch_one(name) for name in list_names_cache],
            return_exceptions=True
        )

        for result in results:
            if isinstance(result, Exception):
                continue

            list_name, items = result
            list_items_cache[list_name] = items

    async def add_list_click(e):
        try:
            raw_input = (list_name_input.value or "").strip()
            base_name = raw_input if raw_input else datetime.datetime.now().strftime("%Y-%m-%d")

            current_lists = await request_json(
                "GET",
                f"{DB_URL}/metadata/lists.json?auth={user_token['id']}"
            )

            if not isinstance(current_lists, dict):
                current_lists = {}

            final_name = make_unique_list_name(base_name, set(current_lists.keys()))

            await request_json(
                "PATCH",
                f"{DB_URL}/metadata/lists.json?auth={user_token['id']}",
                {final_name: True}
            )

            if final_name not in list_names_cache:
                list_names_cache.append(final_name)
                list_names_cache.sort(reverse=True)

            list_items_cache[final_name] = {}

            list_name_input.value = ""
            err_text.value = ""

            render_home_lists()
            show_item_screen(final_name)

        except Exception as ex:
            err_text.value = f"❌ 新增清單失敗: {repr(ex)}"
            page.update()

    async def delete_list_remote(list_name):
        try:
            await asyncio.gather(
                request_json(
                    "DELETE",
                    f"{DB_URL}/metadata/lists/{list_name}.json?auth={user_token['id']}"
                ),
                request_json(
                    "DELETE",
                    f"{DB_URL}/shopping_lists/{list_name}.json?auth={user_token['id']}"
                )
            )

        except Exception as ex:
            err_text.value = f"❌ 背景刪除清單失敗: {repr(ex)}"
            page.update()

    async def delete_current_list(e):
        list_name = current_list["name"]

        if not list_name:
            err_text.value = "❌ 目前沒有可刪除的清單"
            page.update()
            return

        if list_name in list_names_cache:
            list_names_cache.remove(list_name)

        list_items_cache.pop(list_name, None)

        current_list["name"] = None
        err_text.value = ""

        render_home_lists()
        show_home_screen()

        page.run_task(delete_list_remote, list_name)

    async def save_history_item(name):
        try:
            await request_json(
                "PATCH",
                f"{DB_URL}/metadata/history.json?auth={user_token['id']}",
                {name: {"active": True}}
            )

        except Exception as ex:
            print(f"歷史項目儲存失敗: {repr(ex)}")

    async def add_item_to_current_list(name, qty, clear_input=True):
        list_name = current_list["name"]

        if not list_name:
            err_text.value = "❌ 請先選擇清單"
            page.update()
            return

        if not name:
            err_text.value = "❌ 請輸入項目名稱"
            page.update()
            return

        try:
            new_item_data = {
                "name": name,
                "qty": qty,
                "bought": False,
                "created_at": datetime.datetime.now().isoformat()
            }

            post_data = await request_json(
                "POST",
                f"{DB_URL}/shopping_lists/{list_name}.json?auth={user_token['id']}",
                new_item_data
            )

            if not isinstance(post_data, dict):
                await fetch_items(list_name, show_loading=True)
                return

            new_item_id = post_data.get("name")

            if not new_item_id:
                await fetch_items(list_name, show_loading=True)
                return

            old_items = list_items_cache.get(list_name, {})
            list_items_cache[list_name] = {
                new_item_id: new_item_data,
                **old_items
            }

            if len(items_view.controls) == 1 and isinstance(items_view.controls[0], ft.Text):
                items_view.controls.clear()

            items_view.controls.insert(
                0,
                render_item_row(list_name, new_item_id, new_item_data)
            )

            scroll_items_to_top()

            if name not in history_name_set:
                history_name_set.add(name)

                old_options = item_dropdown.options or []
                item_dropdown.options = [make_option(name)] + old_options

            if clear_input:
                clear_item_dropdown()
                main_qty_text.value = "1"

            err_text.value = ""
            page.update()

            page.run_task(save_history_item, name)

        except Exception as ex:
            err_text.value = f"❌ 新增項目失敗: {repr(ex)}"
            page.update()

    async def add_item_final(e):
        name = get_item_dropdown_text()
        qty = main_qty_text.value

        await add_item_to_current_list(name, qty, clear_input=True)

    add_item_button.on_click = add_item_final

    async def delete_selected_history_item(e):
        history_name = get_item_dropdown_text()

        if not history_name:
            err_text.value = "❌ 請先選擇要刪除的歷史項目"
            page.update()
            return

        if history_name not in history_name_set:
            err_text.value = "❌ 這不是歷史項目，無法刪除"
            page.update()
            return

        try:
            await request_json(
                "DELETE",
                f"{DB_URL}/metadata/history/{history_name}.json?auth={user_token['id']}"
            )

            clear_item_dropdown()
            err_text.value = ""

            await load_metadata(selected_list=current_list["name"])

        except Exception as ex:
            err_text.value = f"❌ 刪除歷史項目失敗: {repr(ex)}"
            page.update()

    async def load_metadata(selected_list=None):
        meta = await request_json(
            "GET",
            f"{DB_URL}/metadata.json?auth={user_token['id']}"
        )

        if not isinstance(meta, dict):
            meta = {}

        lists_raw = meta.get("lists", {})
        if not isinstance(lists_raw, dict):
            lists_raw = {}

        list_names_cache.clear()
        list_names_cache.extend(sorted(lists_raw.keys(), reverse=True))

        history_raw = meta.get("history", {})
        if not isinstance(history_raw, dict):
            history_raw = {}

        history_keys = [
            h for h in history_raw.keys()
            if h not in ["True", "{'active': True}"]
        ]

        history_name_set.clear()
        history_name_set.update(history_keys)

        item_dropdown.options = [
            make_option(h)
            for h in reversed(history_keys[-100:])
        ]

        quick_raw = meta.get("quick_items", [])

        quick_items.clear()

        if isinstance(quick_raw, list):
            for q in quick_raw:
                if isinstance(q, str) and q.strip():
                    quick_items.append(q.strip()[:QUICK_NAME_MAX_LEN])

        elif isinstance(quick_raw, dict):
            for q in quick_raw.keys():
                if isinstance(q, str) and q.strip():
                    quick_items.append(q.strip()[:QUICK_NAME_MAX_LEN])

        del quick_items[QUICK_ITEM_LIMIT:]

        refresh_quick_ui()
        render_home_lists()

        if selected_list:
            show_item_screen(selected_list)
        else:
            show_home_screen()

    async def process_login(e):
        email = (email_in.value or "").strip()
        password = (pass_in.value or "").strip()

        if not email or not password:
            err_text.value = "❌ 請輸入帳號與密碼"
            page.update()
            return

        try:
            data = await request_json(
                "POST",
                AUTH_SIGNIN,
                {
                    "email": email,
                    "password": password,
                    "returnSecureToken": True
                }
            )

            if not isinstance(data, dict) or "localId" not in data:
                error_message = ""

                if isinstance(data, dict):
                    error_message = data.get("error", {}).get("message", "")

                err_text.value = f"❌ 帳密錯誤: {error_message}"
                page.update()
                return

            uid = data["localId"]
            user_token["id"] = data.get("idToken")

            user_data = await request_json(
                "GET",
                f"{DB_URL}/users/{uid}.json?auth={user_token['id']}"
            )

            if isinstance(user_data, dict) and user_data.get("is_approved"):
                await prefs.set("shopping_email", email)
                await prefs.set("shopping_password", password)

                login_container.visible = False
                shopping_container.visible = True
                err_text.value = ""

                await load_metadata()

            else:
                err_text.value = "⏳ 尚未通過審核"
                page.update()

        except Exception as e:
            err_text.value = f"❌ 連線失敗: {repr(e)}"
            page.update()

    async def process_register(e):
        email = (email_in.value or "").strip()
        password = (pass_in.value or "").strip()

        if not email or not password:
            err_text.value = "❌ 請輸入帳號與密碼"
            page.update()
            return

        try:
            auth_data = await request_json(
                "POST",
                AUTH_SIGNUP,
                {
                    "email": email,
                    "password": password,
                    "returnSecureToken": True
                }
            )

            if isinstance(auth_data, dict) and "localId" in auth_data:
                uid = auth_data["localId"]
                temp_token = auth_data.get("idToken")

                await request_json(
                    "PUT",
                    f"{DB_URL}/users/{uid}.json?auth={temp_token}",
                    {
                        "email": email,
                        "is_approved": False
                    }
                )

                err_text.value = "✅ 註冊成功，請聯繫管理員"
                page.update()

            else:
                error_message = ""

                if isinstance(auth_data, dict):
                    error_message = auth_data.get("error", {}).get("message", "")

                err_text.value = f"❌ 註冊失敗: {error_message}"
                page.update()

        except Exception as e:
            err_text.value = f"❌ 註冊失敗: {repr(e)}"
            page.update()

    home_screen = ft.Column(
        visible=True,
        width=700,
        height=820,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=10,
        controls=[
            ft.Text("清單總覽", size=24, weight="bold"),

            ft.Row(
                [
                    list_name_input,
                    ft.IconButton(
                        ft.Icons.ADD_BOX,
                        icon_color="green",
                        tooltip="新增清單",
                        on_click=add_list_click
                    )
                ],
                alignment=ft.MainAxisAlignment.CENTER
            ),

            err_text,

            home_list_view
        ]
    )

    quick_section = ft.Container(
        width=235,
        padding=6,
        border=ft.Border.all(1, "grey"),
        border_radius=10,
        content=ft.Column(
            [
                ft.Text("快捷項目", size=15, weight="bold"),
                quick_grid
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=4
        )
    )

    item_add_section = ft.Container(
        width=220,
        padding=6,
        border=ft.Border.all(1, "grey"),
        border_radius=10,
        content=ft.Column(
            [
                ft.Text("新增項目", size=15, weight="bold"),

                ft.Row(
                    [
                        item_dropdown,

                        ft.IconButton(
                            ft.Icons.DELETE_OUTLINE,
                            icon_color="red",
                            tooltip="刪除目前選到的歷史項目",
                            icon_size=18,
                            width=32,
                            height=32,
                            on_click=lambda e: page.run_task(delete_selected_history_item, e)
                        )
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=0
                ),

                selected_item_text,

                ft.Row(
                    [
                        ft.IconButton(
                            ft.Icons.REMOVE_CIRCLE_OUTLINE,
                            icon_size=18,
                            width=30,
                            height=30,
                            on_click=decrease_main_qty
                        ),
                        main_qty_text,
                        ft.IconButton(
                            ft.Icons.ADD_CIRCLE_OUTLINE,
                            icon_size=18,
                            width=30,
                            height=30,
                            on_click=increase_main_qty
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=0
                ),

                add_item_button
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=3
        )
    )

    current_list_name_container = ft.Container(
        width=330,
        alignment=ft.Alignment.CENTER,
        content=current_selected_list_text
    )

    left_panel = ft.Container(
        width=360,
        height=760,
        padding=8,
        border=ft.Border.all(1, "grey"),
        border_radius=10,
        content=ft.Column(
            [
                ft.Row(
                    [
                        ft.Button(
                            "←",
                            width=46,
                            height=34,
                            on_click=show_home_screen
                        ),

                        ft.IconButton(
                            ft.Icons.DELETE_OUTLINE,
                            icon_color="red",
                            tooltip="刪除目前清單",
                            on_click=lambda e: page.run_task(delete_current_list, e)
                        )
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),

                current_list_name_container,

                ft.Divider(),

                items_view
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=6
        )
    )

    right_sidebar = ft.Container(
        width=235,
        height=760,
        padding=6,
        border=ft.Border.all(1, "grey"),
        border_radius=10,
        content=ft.Column(
            [
                quick_section,
                item_add_section
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=6
        )
    )

    item_screen = ft.Row(
        visible=False,
        width=620,
        height=800,
        alignment=ft.MainAxisAlignment.CENTER,
        vertical_alignment=ft.CrossAxisAlignment.START,
        spacing=8,
        wrap=False,
        controls=[
            left_panel,
            right_sidebar
        ]
    )

    quick_edit_screen = ft.Column(
        visible=False,
        width=700,
        height=820,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=8,
        controls=[
            ft.Row(
                [
                    ft.Button(
                        "←",
                        width=46,
                        height=34,
                        on_click=back_from_quick_edit
                    )
                ],
                alignment=ft.MainAxisAlignment.START
            ),

            ft.Text("編輯快捷項目", size=18, weight="bold"),

            ft.Container(
                width=390,
                height=700,
                padding=8,
                border=ft.Border.all(1, "grey"),
                border_radius=10,
                content=ft.Column(
                    [
                        ft.Row(
                            [
                                quick_new_input,
                                ft.Button(
                                    "新增",
                                    width=58,
                                    height=34,
                                    style=ft.ButtonStyle(
                                        text_style=ft.TextStyle(size=11)
                                    ),
                                    on_click=lambda e: page.run_task(add_quick_item, e)
                                )
                            ],
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=4
                        ),

                        quick_edit_list
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=6
                )
            )
        ]
    )

    shopping_container.controls = [
        home_screen,
        item_screen,
        quick_edit_screen
    ]

    login_container = ft.Column(
        [
            ft.Text("荳比小窩購物清單", size=25, weight="bold"),
            email_in := ft.TextField(label="Email", width=300),
            pass_in := ft.TextField(label="密碼", password=True, width=300),
            ft.Button("登入", on_click=process_login, width=300),
            ft.Button("註冊", on_click=process_register, width=300),
            err_text
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        alignment=ft.MainAxisAlignment.CENTER
    )

    def apply_responsive_layout(e=None):
        screen_width = int(page.width or page.window_width or 720)
        screen_height = int(page.height or page.window_height or 850)
        is_mobile = screen_width < 650

        is_mobile_layout["value"] = is_mobile
        page.scroll = ft.ScrollMode.AUTO

        def clamp(value, min_value, max_value):
            return max(min_value, min(value, max_value))

        if is_mobile:
            usable_width = max(280, screen_width - 8)
            usable_height = max(420, screen_height - 8)

            row_gap = 2 if usable_width < 360 else 4

            # Keep mobile as left-list + right-shortcuts, but calculate both sides from real screen width.
            right_width = int(usable_width * 0.42)
            right_width = clamp(right_width, 118, 190)

            left_width = usable_width - right_width - row_gap
            if left_width < 145:
                left_width = 145
                right_width = usable_width - left_width - row_gap

            right_width = max(108, right_width)

            left_padding = 4 if usable_width < 360 else 5
            right_padding = 3 if usable_width < 360 else 4
            section_padding = 3 if usable_width < 360 else 4

            left_content_width = max(120, left_width - left_padding * 2 - 4)
            right_content_width = max(96, right_width - right_padding * 2 - 4)
            section_inner_width = max(88, right_content_width - section_padding * 2 - 4)

            shopping_container.width = usable_width
            shopping_container.height = None

            home_screen.width = usable_width
            home_screen.height = None

            home_list_view.width = usable_width - 8
            home_list_view.height = max(360, usable_height - 190)

            item_screen.width = usable_width
            item_screen.height = None
            item_screen.wrap = False
            item_screen.spacing = row_gap
            item_screen.alignment = ft.MainAxisAlignment.START

            item_screen.controls = [
                left_panel,
                right_sidebar
            ]

            left_panel.width = left_width
            left_panel.height = None
            left_panel.padding = left_padding

            right_sidebar.width = right_width
            right_sidebar.height = None
            right_sidebar.padding = right_padding

            quick_section.width = right_content_width
            quick_section.padding = section_padding

            quick_grid.width = section_inner_width
            quick_grid.height = max(180, min(260, int(usable_height * 0.36)))

            item_add_section.width = right_content_width
            item_add_section.padding = section_padding

            items_view.width = left_content_width
            items_view.height = max(360, usable_height - 220)

            current_list_name_container.width = left_content_width

            list_name_input.width = min(300, usable_width - 70)

            item_dropdown.width = max(72, section_inner_width - 34)
            item_dropdown.menu_width = min(220, max(160, screen_width - 24))
            item_dropdown.menu_height = max(180, min(240, usable_height - 160))

            selected_item_text.width = section_inner_width

            add_item_button.width = section_inner_width
            add_item_button.height = 34

            quick_edit_box = quick_edit_screen.controls[2]

            quick_edit_screen.width = usable_width
            quick_edit_screen.height = usable_height
            quick_edit_screen.scroll = ft.ScrollMode.AUTO

            quick_edit_box.width = usable_width - 12
            quick_edit_box.height = max(320, usable_height - 96)
            quick_edit_box.padding = 6

            quick_edit_list.width = quick_edit_box.width - 16
            quick_edit_list.height = max(220, quick_edit_box.height - 76)

            quick_new_input.width = max(150, min(quick_edit_list.width - 68, quick_edit_box.width - 82))

        else:
            shopping_container.width = 700
            shopping_container.height = 820

            home_screen.width = 700
            home_screen.height = 820

            home_list_view.width = 660
            home_list_view.height = 640

            item_screen.width = 620
            item_screen.height = 800
            item_screen.wrap = False
            item_screen.spacing = 8
            item_screen.alignment = ft.MainAxisAlignment.CENTER

            item_screen.controls = [
                left_panel,
                right_sidebar
            ]

            left_panel.width = 360
            left_panel.height = 760
            left_panel.padding = 8

            right_sidebar.width = 235
            right_sidebar.height = 760
            right_sidebar.padding = 6

            quick_section.width = 235
            quick_section.padding = 6

            quick_grid.width = 235
            quick_grid.height = 260

            item_add_section.width = 220
            item_add_section.padding = 6

            items_view.width = 340
            items_view.height = 650

            current_list_name_container.width = 330

            list_name_input.width = 300

            item_dropdown.width = 150
            item_dropdown.menu_width = 220
            item_dropdown.menu_height = 240

            selected_item_text.width = None

            add_item_button.width = 160
            add_item_button.height = 36

            quick_edit_box = quick_edit_screen.controls[2]

            quick_edit_screen.width = 700
            quick_edit_screen.height = 820
            quick_edit_screen.scroll = None

            quick_edit_box.width = 390
            quick_edit_box.height = 700
            quick_edit_box.padding = 8

            quick_edit_list.width = 360
            quick_edit_list.height = 620
            quick_new_input.width = 200

        refresh_quick_grid()
        refresh_quick_edit_list()

        if current_list["name"]:
            render_items_from_cache(current_list["name"])

        page.update()

    page.on_resize = apply_responsive_layout

    page.add(login_container, shopping_container)

    apply_responsive_layout()

    refresh_quick_ui()

    async def auto_login():
        await asyncio.sleep(0.5)

        try:
            has_email = await prefs.contains_key("shopping_email")
            has_password = await prefs.contains_key("shopping_password")

            if not has_email or not has_password:
                return

            saved_email = await prefs.get("shopping_email")
            saved_password = await prefs.get("shopping_password")

            if not saved_email or not saved_password:
                return

            email_in.value = saved_email
            pass_in.value = saved_password
            page.update()

            print(f"自動登入帳號: {saved_email}")

            await process_login(None)

        except Exception as e:
            print(f"自動登入失敗: {repr(e)}")

    page.run_task(auto_login)


if __name__ == "__main__":
    ft.run(main)