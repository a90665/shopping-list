from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
BUILD_WEB = ROOT / "build" / "web"
INDEX = BUILD_WEB / "index.html"

if not INDEX.exists():
    raise SystemExit("找不到 build/web/index.html，請先執行：flet build web --no-cdn")

shutil.copy2(ROOT / "service-worker.js", BUILD_WEB / "service-worker.js")
shutil.copy2(ROOT / "manifest.json", BUILD_WEB / "manifest.json")

html = INDEX.read_text(encoding="utf-8")

loading_css = """
<style id="shopping-list-loading-style">
  #startup-loading {
    position: fixed;
    inset: 0;
    z-index: 999999;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    background: #ffffff;
    color: #222222;
    font-family: Arial, 'Microsoft JhengHei', sans-serif;
  }
  #startup-loading .title {
    font-size: 24px;
    font-weight: 700;
    margin-bottom: 10px;
  }
  #startup-loading .sub {
    font-size: 15px;
    color: #666666;
  }
</style>
"""

loading_html = """
<div id="startup-loading">
  <div class="title">荳比小窩購物清單</div>
  <div class="sub">載入中...</div>
</div>
"""

sw_script = """
<script id="shopping-list-sw-register">
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('./service-worker.js').catch(function () {});
    });
  }

  window.addEventListener('flutter-first-frame', function () {
    var loading = document.getElementById('startup-loading');
    if (loading) loading.remove();
  });

  setTimeout(function () {
    var loading = document.getElementById('startup-loading');
    if (loading) loading.remove();
  }, 15000);
</script>
"""

if 'rel="manifest"' not in html and "rel='manifest'" not in html:
    html = html.replace("</head>", '  <link rel="manifest" href="manifest.json">\n</head>')

if "shopping-list-loading-style" not in html:
    html = html.replace("</head>", loading_css + "\n</head>")

if "startup-loading" not in html:
    html = html.replace("<body>", "<body>\n" + loading_html, 1)

if "shopping-list-sw-register" not in html:
    html = html.replace("</body>", sw_script + "\n</body>")

INDEX.write_text(html, encoding="utf-8")

print("完成：已加入 loading 畫面、manifest、service-worker 快取。")
print("輸出位置：", BUILD_WEB)
