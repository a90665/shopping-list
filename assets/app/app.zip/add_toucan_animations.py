from __future__ import annotations

from datetime import datetime
from pathlib import Path
import shutil


PROJECT_DIR = Path(__file__).resolve().parent
MAIN_PATH = PROJECT_DIR / "main.py"

WALK_DIR = PROJECT_DIR / "assets" / "toucan_walk"
REQUIRED_IMAGES = [
    WALK_DIR / "walk_left_forward.png",
    WALK_DIR / "walk_right_forward.png",
    WALK_DIR / "apple_hold.png",
    WALK_DIR / "apple_eat.png",
]


def backup_file(path: Path) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = path.with_name(
        f"{path.stem}_before_walk_fix_{stamp}{path.suffix}"
    )
    shutil.copy2(path, backup)
    return backup


def replace_once(
    text: str,
    old: str,
    new: str,
    label: str,
    *,
    allow_missing: bool = False,
) -> tuple[str, bool]:
    count = text.count(old)

    if count == 0 and allow_missing:
        return text, False

    if count != 1:
        raise RuntimeError(
            f"{label}：預期找到 1 處，實際找到 {count} 處。"
        )

    return text.replace(old, new, 1), True


def require_files() -> None:
    missing = [
        path
        for path in [MAIN_PATH, *REQUIRED_IMAGES]
        if not path.is_file()
    ]

    if missing:
        detail = "\n".join(f"  - {path}" for path in missing)
        raise FileNotFoundError(
            "缺少必要檔案：\n"
            f"{detail}"
        )


def patch_visibility(text: str) -> tuple[str, bool]:
    old = '''    def toucan_is_visible():
        return bool(
            not system_closed_by_idle["value"]
            and shopping_container.visible
            and item_screen is not None
            and item_screen.visible
        )
'''

    new = '''    def toucan_is_visible():
        if system_closed_by_idle["value"]:
            return False

        if not shopping_container.visible:
            return False

        home_visible = bool(
            home_screen is not None
            and home_screen.visible
        )
        item_visible = bool(
            item_screen is not None
            and item_screen.visible
        )

        # 首頁清單與清單內容頁都顯示走路動畫。
        # 快捷編輯頁不顯示。
        return home_visible or item_visible
'''

    return replace_once(
        text,
        old,
        new,
        "修正走路動畫顯示條件",
        allow_missing=True,
    )


def ensure_footer_in_controls(text: str) -> tuple[str, bool]:
    if "            toucan_footer\n" in text:
        return text, False

    old = '''        shopping_container.controls = [
            home_screen,
            item_screen,
            quick_edit_screen
        ]
'''

    new = '''        shopping_container.controls = [
            home_screen,
            item_screen,
            quick_edit_screen,
            toucan_footer
        ]
'''

    return replace_once(
        text,
        old,
        new,
        "將走路動畫加入 shopping_container",
    )


def patch_mobile_home_layout(text: str) -> tuple[str, int]:
    changed = 0

    old_height = (
        "                home_screen.height = item_area_height\n"
    )
    new_height = (
        "                home_screen.height = max(\n"
        "                    320,\n"
        "                    item_area_height - TOUCAN_FOOTER_HEIGHT\n"
        "                )\n"
    )

    if old_height in text:
        text = text.replace(old_height, new_height, 1)
        changed += 1

    old_list_height = (
        "                home_list_view.height = "
        "max(260, item_area_height - 122)\n"
    )
    new_list_height = (
        "                home_list_view.height = "
        "max(180, home_screen.height - 122)\n"
    )

    if old_list_height in text:
        text = text.replace(
            old_list_height,
            new_list_height,
            1,
        )
        changed += 1

    return text, changed


def patch_desktop_home_layout(text: str) -> tuple[str, int]:
    changed = 0

    old_height = "                home_screen.height = 820\n"
    new_height = "                home_screen.height = 730\n"

    if old_height in text:
        text = text.replace(old_height, new_height, 1)
        changed += 1

    old_list_height = (
        "                home_list_view.height = 640\n"
    )
    new_list_height = (
        "                home_list_view.height = 550\n"
    )

    if old_list_height in text:
        text = text.replace(
            old_list_height,
            new_list_height,
            1,
        )
        changed += 1

    return text, changed


def patch_image_update(text: str) -> tuple[str, bool]:
    old = '''        async def update_toucan_image(src):
            toucan_image.src = src
            try:
                toucan_image.update()
            except Exception:
                page.update()
'''

    new = '''        async def update_toucan_image(src):
            toucan_image.src = src

            # Web/Pyodide 下直接更新整頁較穩定，
            # 避免只更新 Image 時沒有重新繪製。
            page.update()
            await asyncio.sleep(0)
'''

    return replace_once(
        text,
        old,
        new,
        "修正 Web 圖片更新方式",
        allow_missing=True,
    )


def ensure_animation_task(text: str) -> tuple[str, bool]:
    task_line = "    page.run_task(toucan_animation_loop)\n"

    if task_line in text:
        return text, False

    if "    async def toucan_animation_loop():" not in text:
        raise RuntimeError(
            "找不到 toucan_animation_loop()，"
            "代表 main.py 尚未完整加入走路動畫。"
        )

    anchor = "    page.run_task(auto_login)\n"

    if anchor not in text:
        raise RuntimeError(
            "找不到 page.run_task(auto_login)，"
            "無法加入走路動畫啟動指令。"
        )

    text = text.replace(
        anchor,
        anchor + task_line,
        1,
    )
    return text, True


def add_diagnostic_log(text: str) -> tuple[str, bool]:
    marker = 'print("大嘴鳥走路動畫已啟動")'

    if marker in text:
        return text, False

    old = '''    async def toucan_animation_loop():
        walk_index = 0
        next_event_check = None
'''

    new = '''    async def toucan_animation_loop():
        print("大嘴鳥走路動畫已啟動")
        walk_index = 0
        next_event_check = None
'''

    return replace_once(
        text,
        old,
        new,
        "加入動畫啟動診斷",
        allow_missing=True,
    )


def main() -> int:
    require_files()

    raw = MAIN_PATH.read_bytes()

    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as ex:
        raise RuntimeError(
            "main.py 不是 UTF-8，已停止修改。"
        ) from ex

    if "TOUCAN_ANIMATION_BEGIN" not in text:
        raise RuntimeError(
            "main.py 找不到 TOUCAN_ANIMATION_BEGIN，"
            "代表之前的走路動畫沒有完整寫入。"
        )

    backup = backup_file(MAIN_PATH)

    text, visibility_changed = patch_visibility(text)
    text, footer_added = ensure_footer_in_controls(text)
    text, mobile_changes = patch_mobile_home_layout(text)
    text, desktop_changes = patch_desktop_home_layout(text)
    text, update_changed = patch_image_update(text)
    text, task_added = ensure_animation_task(text)
    text, log_added = add_diagnostic_log(text)

    compile(text, str(MAIN_PATH), "exec")
    MAIN_PATH.write_bytes(text.encode("utf-8"))

    print()
    print("走路動畫修正完成。")
    print(f"main.py 備份：{backup}")
    print(f"顯示條件修正：{visibility_changed}")
    print(f"補上 footer：{footer_added}")
    print(f"手機版版面修正數：{mobile_changes}")
    print(f"桌面版版面修正數：{desktop_changes}")
    print(f"Web 圖片更新修正：{update_changed}")
    print(f"補上動畫啟動指令：{task_added}")
    print(f"補上診斷訊息：{log_added}")
    print()
    print("接著執行：")
    print(
        r".\venv\Scripts\python.exe "
        r"-m py_compile .\main.py"
    )
    print("沒有輸出後重新 build web。")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as ex:
        print()
        print(f"[ERROR] {ex}")
        raise
